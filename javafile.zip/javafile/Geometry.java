import java.util.Scanner;

class Rectangle {
    double length;
    double width;

    public Rectangle(double length, double width) {
        this.length = length; 
        this.width = width;
    }

    public double area() {
        return length * width;
    }

    public double perimeter() {
        return 2 * (length + width);
    }
}

class Box extends Rectangle {
    double height;

    public Box(double length, double width, double height) {
        super(length, width); 
        this.height = height; 
    }

    public double volume() {
        return area() * height; 
    }

    public double surfaceArea() {
        return 2 * (area() + (length * height) + (width * height));
    }
}

public class Geometry {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the length of the rectangle: ");
        double length = scanner.nextDouble();
        System.out.print("Enter the width of the rectangle: ");
        double width = scanner.nextDouble();

        Rectangle rectangle = new Rectangle(length, width);
        System.out.println("Rectangle Area: " + rectangle.area());
        System.out.println("Rectangle Perimeter: " + rectangle.perimeter());

        System.out.print("Enter the height of the box: ");
        double height = scanner.nextDouble();

        Box box = new Box(length, width, height);
        System.out.println("Box Volume: " + box.volume());
        System.out.println("Box Surface Area: " + box.surfaceArea());

        scanner.close();
    }
}