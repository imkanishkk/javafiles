import java.awt.*;
import javax.swing.*;

public class LayoutDemo extends JFrame {

    public LayoutDemo() {
        setTitle("GridLayout and CardLayout Example");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(2, 2));
        for (int i = 1; i <= 4; i++) {
            gridPanel.add(new JButton("Button " + i));
        }

        JPanel cardPanel = new JPanel(new CardLayout());
        cardPanel.add(createCard("Card 1", Color.RED), "Card 1");
        cardPanel.add(createCard("Card 2", Color.GREEN), "Card 2");
        cardPanel.add(createCard("Card 3", Color.BLUE), "Card 3");

        JPanel buttonPanel = new JPanel();
        for (String cardName : new String[]{"Card 1", "Card 2", "Card 3"}) {
            JButton button = new JButton("Show " + cardName);
            button.addActionListener(e -> switchCard(cardPanel, cardName));
            buttonPanel.add(button);
        }

        add(gridPanel, BorderLayout.NORTH);
        add(cardPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    private JPanel createCard(String name, Color color) {
        JPanel card = new JPanel();
        card.setBackground(color);
        card.add(new JLabel(name));
        return card;
    }
    private void switchCard(JPanel cardPanel, String cardName) {
        CardLayout cl = (CardLayout) cardPanel.getLayout();
        cl.show(cardPanel, cardName);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LayoutDemo().setVisible(true));
    }
}