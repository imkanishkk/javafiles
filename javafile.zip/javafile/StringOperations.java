import java.util.Scanner;

class MyString {
    private String str;

    public MyString(String str) {
        this.str = str;
    }

    public boolean equals(MyString other) {
        return this.str.equals(other.str);
    }

    public String reverse() {
        StringBuilder reversed = new StringBuilder(str);
        return reversed.reverse().toString();
    }

    public String changeCase() {
        StringBuilder changedCase = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isUpperCase(c)) {
                changedCase.append(Character.toLowerCase(c));
            } else {
                changedCase.append(Character.toUpperCase(c));
            }
        }
        return changedCase.toString();
    }

    public String getString() {
        return str;
    }
}

public class StringOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String firstInput = scanner.nextLine();
        MyString firstString = new MyString(firstInput);

        System.out.print("Enter the second string: ");
        String secondInput = scanner.nextLine();
        MyString secondString = new MyString(secondInput);

        if (firstString.equals(secondString)) {
            System.out.println("The strings are equal.");
        } else {
            System.out.println("The strings are not equal.");
        }

        System.out.println("Reversed first string: " + firstString.reverse());
        System.out.println("Changed case of first string: " + firstString.changeCase());

        scanner.close();
    }
}