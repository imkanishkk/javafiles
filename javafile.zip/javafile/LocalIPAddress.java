import java.net.InetAddress;
import java.net.UnknownHostException;

public class LocalIPAddress {
    public static void main(String[] args) {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            String ipAddress = localHost.getHostAddress();
            String hostName = localHost.getHostName();
            System.out.println("Host Name: " + hostName);
            System.out.println("IP Address: " + ipAddress);
        } 
        catch (UnknownHostException e) {
            System.err.println("Unable to retrieve IP address: " + e.getMessage());
        }
    }
}