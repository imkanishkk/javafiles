import javax.swing.*;
import java.awt.*;

public class LayoutExample extends JFrame {

    public LayoutExample() {
        setTitle("FlowLayout and BorderLayout Example");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel flowPanel = new JPanel(new FlowLayout());
        flowPanel.add(new JButton("Button 1"));
        flowPanel.add(new JButton("Button 2"));
        flowPanel.add(new JButton("Button 3"));

        add(flowPanel, BorderLayout.CENTER);

        add(new JButton("North"), BorderLayout.NORTH);
        add(new JButton("South"), BorderLayout.SOUTH);
        add(new JButton("East"), BorderLayout.EAST);
        add(new JButton("West"), BorderLayout.WEST);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LayoutExample example = new LayoutExample();
            example.setVisible(true);
        });
    }
}