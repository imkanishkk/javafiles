import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuExample extends JFrame implements ActionListener {
    public MenuExample() {
        setTitle("Menu Example");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");

        addMenuItem(fileMenu, "New");
        addMenuItem(fileMenu, "Open");
        addMenuItem(fileMenu, "Exit");
        fileMenu.addSeparator();

        addMenuItem(editMenu, "Cut");
        addMenuItem(editMenu, "Copy");
        addMenuItem(editMenu, "Paste");

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        setJMenuBar(menuBar);
    }
    private void addMenuItem(JMenu menu, String itemName) {
        JMenuItem menuItem = new JMenuItem(itemName);
        menuItem.addActionListener(this);
        menu.add(menuItem);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command) {
            case "New": JOptionPane.showMessageDialog(this, "New File Created"); break;
            case "Open": JOptionPane.showMessageDialog(this, "Open File Dialog"); break;
            case "Exit": System.exit(0); break;
            case "Cut": JOptionPane.showMessageDialog(this, "Cut Action"); break;
            case "Copy": JOptionPane.showMessageDialog(this, "Copy Action"); break;
            case "Paste": JOptionPane.showMessageDialog(this, "Paste Action"); break;
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuExample().setVisible(true));
    }
}