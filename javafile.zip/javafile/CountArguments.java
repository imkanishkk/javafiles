public class CountArguments {
    public static void main(String[] args) {
        
        int numberOfArguments = args.length;

        System.out.println("Number of arguments provided: " + numberOfArguments);
        
        if (numberOfArguments > 0) {
            System.out.println("Arguments provided:");
            for (int i = 0; i < numberOfArguments; i++) {
                System.out.println("Argument " + (i + 1) + ": " + args[i]);
            }
        }
    }
}