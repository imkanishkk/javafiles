public class SumAndAverage {
    public static void main(String[] args) {
        
        if (args.length == 0) {
            System.out.println("Please provide numbers as command-line arguments.");
            return;
        }

        
        double sum = 0;

        
        for (String arg : args) {
            try {
                
                double number = Double.parseDouble(arg);
                sum += number;
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format: " + arg);
                return;
            }
        }

        
        double average = sum / args.length;

        
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
    }
}
