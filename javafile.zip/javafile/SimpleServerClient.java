import java.io.*;
import java.net.*;

public class SimpleServerClient {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        new Thread(SimpleServerClient::startServer).start();
        startClient();
    }

    private static void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);
            
            while (true) {
                Socket socket = serverSocket.accept(); 
                System.out.println("New client connected");

                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            System.out.println("Server exception: " + e.getMessage());
        }
    }

    private static void startClient() {
        try {
            Thread.sleep(1000);

            String hostname = "localhost"; 
            try (Socket socket = new Socket(hostname, PORT);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
                String userMessage;
                System.out.println("Enter messages to send to the server (type 'exit' to quit):");
                while (!(userMessage = userInput.readLine()).equalsIgnoreCase("exit")) {
                    out.println(userMessage); 
                    String response = in.readLine(); 
                    System.out.println("Server response: " + response);
                }
            } catch (IOException e) {
                System.out.println("Client exception: " + e.getMessage());
            }
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted: " + e.getMessage());
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
             
            String message;
            while ((message = in.readLine()) != null) {
                System.out.println("Received: " + message);
                out.println("Echo: " + message); 
            }
        } catch (IOException e) {
            System.out.println("Client handler exception: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Could not close socket: " + e.getMessage());
            }
        }
    }
}