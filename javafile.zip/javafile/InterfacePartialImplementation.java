interface Vehicle {

    void start();
    void stop();

    default void honk() {
        System.out.println("Honking the horn!");
    }
}

class Car implements Vehicle {

    @Override
    public void start() {
        System.out.println("Car is starting.");
    }

    @Override
    public void stop() {
        System.out.println("Car is stopping.");
    }
}

class Bike implements Vehicle {

    @Override
    public void start() {
        System.out.println("Bike is starting.");
    }

    @Override
    public void stop() {
        System.out.println("Bike is stopping.");
    }

    @Override
    public void honk() {
        System.out.println("Bike horn: Beep Beep!");
    }
}

public class InterfacePartialImplementation {
    public static void main(String[] args) {
        Vehicle myCar = new Car();
        myCar.start();
        myCar.honk(); // Calls the default method
        myCar.stop();
        System.out.println();
        Vehicle myBike = new Bike();
        myBike.start();
        myBike.honk(); 
        myBike.stop();
    }
}