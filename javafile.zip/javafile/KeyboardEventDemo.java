import javax.swing.*;
import java.awt.event.*;

public class KeyboardEventDemo extends JFrame implements KeyListener {
    private JTextArea textArea;

    public KeyboardEventDemo() {
        setTitle("Keyboard Event Handling Demo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.addKeyListener(this); // Register the key listener
        add(new JScrollPane(textArea)); // Add scroll pane for better usability
    }
    @Override
    public void keyTyped(KeyEvent e) {
        // Handle key typed event
        textArea.append("Key Typed: " + e.getKeyChar() + "\n");
    }
    @Override
    public void keyPressed(KeyEvent e) {
        // Handle key pressed event
        textArea.append("Key Pressed: " + KeyEvent.getKeyText(e.getKeyCode()) + "\n");
    }
    @Override
    public void keyReleased(KeyEvent e) {
        // Handle key released event
        textArea.append("Key Released: " + KeyEvent.getKeyText(e.getKeyCode()) + "\n");
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            KeyboardEventDemo demo = new KeyboardEventDemo();
            demo.setVisible(true);
        });
    }
}