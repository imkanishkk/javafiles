import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DialogBoxExample extends JFrame implements ActionListener {
   
    public DialogBoxExample() {
        setTitle("Dialog Box Example");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
     
        String[] buttonLabels = {"Show Info Dialog", "Show Confirm Dialog", "Show Input Dialog"};
        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.addActionListener(this);
            add(button);
        }
        setLayout(new java.awt.FlowLayout());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Show Info Dialog":
                JOptionPane.showMessageDialog(this, "This is an information dialog.", "Information", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "Show Confirm Dialog":
                if (JOptionPane.showConfirmDialog(this, "Do you want to proceed?", "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(this, "You chose Yes.");
                } else {
                    JOptionPane.showMessageDialog(this, "You chose No.");
                }
                break;
            case "Show Input Dialog":
                String input = JOptionPane.showInputDialog(this, "Enter your name:");
                if (input != null) {
                    JOptionPane.showMessageDialog(this, "Hello, " + input + "!");
                }
                break;
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DialogBoxExample().setVisible(true));
    }
}